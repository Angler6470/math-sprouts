import React, { useState, useEffect } from 'react';

/**
 * Math Sprouts - A math app for children ages 3-8
 * Theme: Growth/Garden aesthetic
 */
function App() {
  // Game state
  const [problem, setProblem] = useState({ num1: 0, num2: 0, answer: 0, options: [], type: '+' });
  const [xp, setXp] = useState(0);
  const [level, setLevel] = useState(1);
  const [garden, setGarden] = useState([]); // Array of plant emojis
  const [plantSize, setPlantSize] = useState(1);
  const [feedback, setFeedback] = useState({ message: '', type: '' });
  const [isAnimating, setIsAnimating] = useState(false);

  // Plant emojis to cycle through
  const plantEmojis = ['🌱', '🌿', '🌻', '🌷', '🌼', '🌵', '🌴', '🍀'];

  // Generate a new problem based on level
  const generateProblem = (currentLevel = level) => {
    let n1, n2, correctAnswer, type = '+';

    if (currentLevel === 1) {
      // Level 1: Sums 1-10
      correctAnswer = Math.floor(Math.random() * 10) + 1;
      n1 = Math.floor(Math.random() * correctAnswer);
      n2 = correctAnswer - n1;
    } else if (currentLevel === 2) {
      // Level 2: Sums 1-20
      correctAnswer = Math.floor(Math.random() * 20) + 1;
      n1 = Math.floor(Math.random() * correctAnswer);
      n2 = correctAnswer - n1;
    } else {
      // Level 3+: Simple subtraction (result >= 0)
      type = '-';
      n1 = Math.floor(Math.random() * 10) + 5; // 5-15
      n2 = Math.floor(Math.random() * n1); // Ensure positive result
      correctAnswer = n1 - n2;
    }

    // Generate 3 unique options including the correct answer
    const optionsSet = new Set([correctAnswer]);
    while (optionsSet.size < 3) {
      const offset = Math.floor(Math.random() * 5) - 2; // +/- 2
      const fake = Math.max(0, correctAnswer + offset);
      if (fake !== correctAnswer) optionsSet.add(fake);
      
      // Fallback if set is still small
      if (optionsSet.size < 3) {
        optionsSet.add(Math.floor(Math.random() * 20));
      }
    }
    
    const optionsArray = Array.from(optionsSet).sort(() => Math.random() - 0.5);

    setProblem({ num1: n1, num2: n2, answer: correctAnswer, options: optionsArray, type });
    setFeedback({ message: '', type: '' });
  };

  // Initialize first problem
  useEffect(() => {
    generateProblem();
  }, []);

  // Trigger confetti based on level
  const triggerConfetti = (currentLevel) => {
    const colors = {
      1: ['#4ADE80', '#22C55E', '#16A34A'], // Greens
      2: ['#60A5FA', '#3B82F6', '#2563EB'], // Blues
      3: ['#FDE047', '#FACC15', '#EAB308'], // Yellows
    };

    const selectedColors = colors[currentLevel] || ['#FF0000', '#00FF00', '#0000FF'];

    window.confetti({
      particleCount: 150,
      spread: 70,
      origin: { y: 0.6 },
      colors: selectedColors
    });
  };

  // Handle answer selection
  const handleAnswer = (selected) => {
    if (selected === problem.answer) {
      // Correct!
      setFeedback({ message: 'Correct! 🌟', type: 'success' });
      setIsAnimating(true);
      
      const newXp = xp + 10; // 10 correct answers = 100%
      
      if (newXp >= 100) {
        // Level Up / Garden Growth!
        triggerConfetti(level);
        
        setTimeout(() => {
          const randomPlant = plantEmojis[Math.floor(Math.random() * plantEmojis.length)];
          setGarden(prev => [...prev, randomPlant]);
          setLevel(prev => prev + 1);
          setXp(0);
          setPlantSize(1);
          setIsAnimating(false);
          generateProblem(level + 1);
        }, 1500);
      } else {
        setXp(newXp);
        setPlantSize(prev => prev + 0.1);
        
        setTimeout(() => {
          setIsAnimating(false);
          generateProblem();
        }, 1000);
      }
    } else {
      // Try again
      setFeedback({ message: 'Try again! 🌱', type: 'error' });
      setTimeout(() => setFeedback({ message: '', type: '' }), 1000);
    }
  };

  return (
    <div className="min-h-screen bg-green-50 flex flex-col items-center p-4 font-sans text-stone-800">
      
      {/* Header */}
      <header className="w-full max-w-md flex flex-col items-center mt-4">
        <div className="flex items-center gap-4 mb-2">
          <div className="w-16 h-16 bg-yellow-200 rounded-full flex items-center justify-center shadow-inner border-4 border-yellow-400">
            <span className="text-3xl" role="img" aria-label="mascot">🐥</span>
          </div>
          <div>
            <h1 className="text-3xl font-bold text-green-700 tracking-tight">Math Sprouts</h1>
            <div className="bg-green-200 px-3 py-0.5 rounded-full text-xs font-bold text-green-800 uppercase">
              Level {level}
            </div>
          </div>
        </div>
      </header>

      {/* Main Game Area */}
      <main className="flex-1 flex flex-col items-center justify-center w-full max-w-md py-8">
        
        {/* The Problem Display */}
        <div className="bg-white rounded-3xl p-8 shadow-xl border-b-8 border-green-200 mb-12 w-full text-center relative">
          <h2 className="text-6xl font-black text-stone-700 mb-4">
            {problem.num1} {problem.type} {problem.num2} = ?
          </h2>
          
          {/* Feedback Text */}
          <div className={`h-8 transition-opacity duration-300 ${feedback.message ? 'opacity-100' : 'opacity-0'}`}>
            <p className={`text-xl font-bold ${feedback.type === 'success' ? 'text-green-500' : 'text-orange-400'}`}>
              {feedback.message}
            </p>
          </div>
        </div>

        {/* The Options (Answer Buttons) */}
        <div className="flex gap-4 mb-24"> {/* Increased margin-bottom to prevent overlap */}
          {problem.options.map((option, index) => (
            <button
              key={index}
              onClick={() => handleAnswer(option)}
              className={`
                w-20 h-20 rounded-full text-3xl font-bold text-white shadow-lg
                transform transition-all duration-200 active:scale-95 hover:scale-110
                ${index === 0 ? 'bg-rose-400 border-b-4 border-rose-600' : ''}
                ${index === 1 ? 'bg-sky-400 border-b-4 border-sky-600' : ''}
                ${index === 2 ? 'bg-amber-400 border-b-4 border-amber-600' : ''}
              `}
            >
              {option}
            </button>
          ))}
        </div>

        {/* The Current Sprout */}
        <div className="relative flex flex-col items-center mb-12">
          <div 
            className="transition-all duration-1000 ease-out transform origin-bottom"
            style={{ 
              transform: `scale(${plantSize})`,
              filter: isAnimating ? 'brightness(1.1)' : 'none'
            }}
          >
            <span className="text-7xl" role="img" aria-label="plant">🌱</span>
          </div>
          <div className="w-32 h-4 bg-stone-300 rounded-full mt-2 shadow-inner"></div>
          <p className="text-stone-400 text-xs font-bold mt-2 uppercase tracking-widest">Current Sprout</p>
        </div>
      </main>

      {/* Garden Visuals (The plants they've grown) */}
      <div className="w-full max-w-md bg-stone-100/50 rounded-t-3xl p-4 border-t-2 border-stone-200 min-h-[100px]">
        <p className="text-center text-stone-400 text-[10px] font-bold uppercase tracking-widest mb-2">My Garden</p>
        <div className="flex flex-wrap justify-center gap-2">
          {garden.length === 0 && <p className="text-stone-300 text-sm italic">Your garden is waiting to grow...</p>}
          {garden.map((plant, i) => (
            <span key={i} className="text-3xl animate-bounce" style={{ animationDelay: `${i * 0.2}s` }}>
              {plant}
            </span>
          ))}
        </div>
      </div>

      {/* XP Bar (Bottom) */}
      <footer className="w-full max-w-md pb-8 pt-4 bg-white px-4 rounded-b-3xl shadow-lg">
        <div className="flex justify-between items-end mb-2 px-2">
          <span className="text-sm font-bold text-green-700 uppercase tracking-wider">Next Plant Progress</span>
          <span className="text-xs font-bold text-green-600">{xp}%</span>
        </div>
        <div className="w-full h-6 bg-stone-100 rounded-full p-1 border-2 border-green-100 shadow-sm overflow-hidden">
          <div 
            className="h-full bg-gradient-to-r from-green-400 to-yellow-400 rounded-full transition-all duration-500 ease-out"
            style={{ width: `${xp}%` }}
          ></div>
        </div>
      </footer>

      <style>{`
        @keyframes bounce-subtle {
          0%, 100% { transform: translateY(0); }
          50% { transform: translateY(-5px); }
        }
        .bouncy {
          animation: bounce-subtle 2s infinite ease-in-out;
        }
      `}</style>
    </div>
  );
}

export default App;
